package com.example.adv_basics

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
